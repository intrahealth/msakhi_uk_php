<section id="content">
	<div class="panel">
		<div class="panel-heading">
			<h3 class="text-center"><?php echo $heading; ?></h3>
		</div>
		<div class="panel-body">
			<div class="row">
				<div class="col-lg-12" style="padding : 20px">
					<canvas id="chart" width="100vw" height="30vh"></canvas>
				</div>
			</div>
			<div class="row">
				<div class="col-lg-12 text-center">
					<a class="btn btn-info">Go To Table Data</a>
				</div>
			</div>
		</div>
	</div>
</section>
<script>
	$(document).ready(function(){
		drawGraph();
	});

	function drawGraph()
	{

		var ctx = $("#chart");
		
	    var data = {
	    labels: [

	        "Male",
	        "Female",
	    ],
	    datasets: [
	        {
	            data: [10,20],
	            backgroundColor: [
	                "#36A2EB",
	                "#FF6384"
	            ],
	            hoverBackgroundColor: [
	                "#36A2EB",
	                "#FF6384"
	            ]
	        }]
		};
		var options = {
			animation : {
				animateRotate : true,
			}
		};
		var myPieChart = new Chart(ctx,{
		    type: 'pie',
		    data: data,
		    options: options
		});
	}
</script>