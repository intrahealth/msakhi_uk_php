						<section id="content">
                    <div class="block-header">
                        <h2>Manage Users</h2>
                    </div>
                
                    <div class="card">
                        <div class="card-header">
                            <h2><b>Add User</b><small>
														Use the form below to add new User
														</small></h2>
                        </div>
                        
							<div class="card-body card-padding">
									<form role="form" method="post" action="">
											<h4>User details</h4>
											
									<div class="form-group fg-line">
											<label for="username">Username</label>
											<input type="text" class="form-control" id="username" name="username" placeholder="Enter user name" value="" required>
									</div>
									
									
									<div class="form-group fg-line">
											<label for="email">Email</label>
											<input type="email" class="form-control" id="email" name="email" placeholder="Enter email" value="" required>
									</div>
									
									<div class="form-group fg-line">
											<label for="password">Password</label>
											<input type="password" class="form-control" id="password" name="password" placeholder="Enter password" value="" required>
									</div>
									<div class="form-group fg-line">
											<label for="repassword">Re-type Password</label>
											<input type="password" class="form-control" id="repassword" name="repassword" placeholder="Enter password Again" value="" required>
									</div>
									<div class="form-group fg-line select">
											<label for="usertype">Select Usertype</label>
											<br>
											<select name="usertype" id="usertype" class="form-control" required>
												<option value="">--select--</option>
												<option value="1">Admin</option>
												<option value="2">User</option>
											</select>
									</div>


								
								<button type="submit" class="btn btn-primary btn-sm m-t-10">Submit</button>
							
							</form>

							</div>
                    </div>
            </section>