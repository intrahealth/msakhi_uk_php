<section id="content">
				<div class="block-header">
						<h2>Manage Asha</h2>
				</div>
                
						<div class="card">
								<div class="card-header">
										<h2><b>Edit Asha</b><small>
										Use the form below to edit new Asha
										</small></h2>
								</div>
                        
														<div class="card-body card-padding">
																<form role="form" method="post" action="">
																		<h4>Asha details</h4>
																
																
				<div class="form-group fg-line">
								<label for="ASHAName">Asha Name In English</label>
								<input type="text" class="form-control" data-toggle="dropdown" id="AshaNameEnglish" name="AshaNameEnglish" placeholder="Enter Asha Name In English " value="<?php echo $Asha_details->ASHAName;?>" required>
						</div>
																
			<div class="form-group fg-line">
					<label for="ASHAName">ASHA Name In Hindi</label>
					<input type="text" class="form-control" data-toggle="dropdown" id="AshaNameHindi" name="AshaNameHindi" placeholder="Enter Asha Name In Hindi " value="<?php echo $Asha_details->ASHAName;?>" required>
			</div>
			
			<div class="form-group fg-line">
							<label for="CHS_ID">CHS ID</label>
							<input type="text" class="form-control" data-toggle="dropdown" id="CHS_ID" name="CHS_ID" placeholder="Enter CHS ID" value="<?php echo $Asha_details->CHS_ID;?>" required>
			</div>
																																
					<button type="submit" class="btn btn-primary btn-sm m-t-10">Submit</button>
								</form>
						</div>
				</div>
</section>