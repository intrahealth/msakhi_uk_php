						<section id="content">
                    <div class="block-header">
                        <h2>Manage Asha</h2>
                    </div>
										
		<?php 
			$tr_msg= $this->session->flashdata('tr_msg');
			$er_msg= $this->session->flashdata('er_msg');

			if(!empty($tr_msg)){ ?>
			<div class="content animate-panel">
				<div class="row">
					<div class="col-md-12">
						<div class="hpanel">
							<div class="alert alert-success alert-dismissable alert1"> <i class="fa fa-check"></i>
							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
							<?php echo $this->session->flashdata('tr_msg');?>. </div>
						</div>
					</div>
				</div>
			</div>
			<?php } else if(!empty($er_msg)){?>
			<div class="content animate-panel">
				<div class="row">
					<div class="col-md-12">
						<div class="hpanel">
							<div class="alert alert-danger alert-dismissable alert1"> <i class="fa fa-check"></i>
							<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
							<?php echo $this->session->flashdata('er_msg');?>. </div>
						</div>
					</div>
				</div>
			</div>
			<?php } ?>	
											
                <div class="card">
								<form method="post">	
									<div class="card-header">
								
									</div>
                    
										<div class="row" style="padding-left : 25px;">
												<div class="col-xs-6 col-xs-4">
													<div class="form-group">
													<div class="fg-line">
														<label for="identifiedby">ANM Code</label>
															<input type="hidden" id="ANMCode" name="ANMCode" >
												<input type="text" class="form-control" id="ANMCodeFake" name="ANMCodeFake" onclick="makeResourceAnmGrid('ANMCode', 'Select ANMCode', 2)" onkeydown="makeResourceAnmGrid(ANMCode); return false;"   placeholder="Select ANMCode" required>
												 </div>
												</div>
												</div>
									
												<div class="col-xs-6 col-xs-4">
													<div class="form-group">
													<div class="fg-line">
														<label for="identifiedby">SubCenter Code</label>
															<input type="hidden" id="SubCenterCode" name="SubCenterCode" >
														<input type="text" class="form-control" id="SubCenterCodeFake" name="SubCenterCodeFake" onclick="makeResourceSubGrids('SubCenterCode' , 'Select SubCenterCode',2)" onkeydown="makeResourceSubGrids(SubCenterCode); return false;" placeholder="Select SubCenterCode" required>
														</div>														
												</div>														
											</div>														
												

												<div class="col-xs-6 col-xs-4">
													<div class="form-group">
													<div class="fg-line">
														<label for="identifiedby">Village Code</label>
															<input type="hidden" id="VillageCode" name="VillageCode" >
														<input type="text" class="form-control" id="VillageCodeFake" name="VillageCodeFake" onclick="makeResourceVillageGrid('VillageCode' , 'Select VillageCode', 2)" onkeydown="makeResourceVillageGrid(VillageCode); return false;" placeholder="Select Village Code" required>
														</div>														
												</div>														
											</div>														
																			
									
														<button class="btn btn-primary btn-sm m-t-10" id="btn_go">Submit</button>
												
												</div>
												</form>
												</div>
												
								
				<div class="card">
							<div class="card-header">
									<h2><b>Add Asha</b><small>
									Use the form below to add new Asha
									</small></h2>
							</div>
							
							<div class="card-body card-padding">
									<form role="form" method="post" action="">
											<h4>Asha details</h4>
														
			<div class="form-group fg-line">
					<label for="ASHAName">Asha Name In English</label>
					<input type="text" class="form-control" data-toggle="dropdown" id="AshaNameEnglish" name="AshaNameEnglish" placeholder="Enter Asha Name In English " value="" required>
			</div>
			
			<div class="form-group fg-line">
					<label for="ASHAName">Asha Name In Hindi</label>
					<input type="text" class="form-control" data-toggle="dropdown" id="AshaNameHindi" name="AshaNameHindi" placeholder="Enter Asha Name In Hindi " value="" required>
			</div>
			
			<div class="form-group fg-line">
					<label for="CHS_ID">CHS ID</label>
						<input type="text" class="form-control" data-toggle="dropdown" id="CHS_ID" name="CHS_ID" placeholder="Enter CHS ID" value="" required>
			</div>
															
																																
		<button type="submit" class="btn btn-primary btn-sm m-t-10">Submit</button>
                            </form>
                        </div>
                    </div>
            </section>
						
						
						
												
												<div id="divIdentifiedByAnmGrid" style="display:none;">
								<table id="tableIdentifiedByAnmGrid" class="table table-striped table-vmiddle">
					<thead>
							<tr>
						<th data-column-id="sno" data-type="numeric" data-order="asc">Sno.</th>
						<th data-column-id="ANMName">ANM Name</th>
						<th data-column-id="ANMCode">ANM Code</th>
						<th data-column-id="commands" data-formatter="commands" data-sortable="false">Commands</th>
							</tr>
					</thead>
												<tbody>
												</tbody>
								</table>
						</div>
						
						
						<div id="divIdentifiedBySubGrid" style="display:none;">
								<table id="tableIdentifiedBySubGrid" class="table table-striped table-vmiddle">
										<thead>
												<tr>
																<th data-column-id="sno" data-type="numeric" data-order="asc">Sno.</th>
																<th data-column-id="SubCenterName">SubCenter Name</th>
																<th data-column-id="SubCenterCode">SubCenter Code</th>
																<th data-column-id="commands" data-formatter="commands" data-sortable="false">Commands</th>
											</tr>
										</thead>
								</table>
						</div>
						
						<div id="divIdentifiedByVillageGrid" style="display:none;">
								<table id="tableIdentifiedByVillageGrid" class="table table-striped table-vmiddle">
										<thead>
												<tr>
																<th data-column-id="sno" data-type="numeric" data-order="asc">Sno.</th>
																<th data-column-id="VillageName">Village Name</th>
																<th data-column-id="VillageCode">Village Code</th>
																<th data-column-id="commands" data-formatter="commands" data-sortable="false">Commands</th>
											</tr>
										</thead>
								</table>
						</div>
						
						
						<script>
						
						var dialogResourceAnmGrid;
                        var bootgridAnmResource;
                        function makeResourceAnmGrid(controlId, title, roleId){
                        
                            dialogResourceAnmGrid = $('#divIdentifiedByAnmGrid').dialog({
                                autoOpen:true,
                                width:screen.width - 200,
                                height:540,
                                title: title,
                                modal: true,
                                buttons: {
                                    Cancel: function() {
                                        dialogResourceAnmGrid.dialog( "close" );
                                    }
                                },
                                close: function() {
                                    $(bootgridAnmResource).bootgrid('destroy');
                                },
                                open: function(){
                                        bootgridAnmResource = $("#tableIdentifiedByAnmGrid").bootgrid({
                                        
                                        ajax: true,
                                        url: "<?php echo site_url("Ajax/getAnmList");?>"    ,
                                        post: function ()
                                        {
                                                /* To accumulate custom parameter with the request object */
                                                return {
                                                        id: "b0df282a-0d67-40e5-8558-c9e93b7befed",
                                                        roleId:roleId
                                                };
                                        },
                    css: {
                        icon: 'zmdi icon',
                        iconColumns: 'zmdi-view-module',
                        iconDown: 'zmdi-expand-more',
                        iconRefresh: 'zmdi-refresh',
                        iconUp: 'zmdi-expand-less'
                    },
                    formatters: {
                                            "commands": function (column, row) {
                                                    return "<a href=\"#\" type=\"button\" class=\"btn btn-icon command-edit waves-effect waves-circle\" data-row-id=\"" + row.ANMCode + "\" data-row-name=\"" + row.ANMName + "\"><span class=\"zmdi zmdi-plus\"></span></a>";                                                  
                                                }
                                        }
                }).on("loaded.rs.jquery.bootgrid", function () {
                                 //Remove event handlers
                                 $(this).find(".command-edit").off();
                                 $(this).find(".command-delete").off();
                                 $(this).find(".command-add").off();

                                 $(this).find(".command-edit").on("click", function (e) {
                                     /* make 2 buttons. one Having Fake suffix will have
                                      name and the one without suffix will be orignal control
                                     and will contain id */
                                     
                                     $('#'+controlId).val($(this).data("row-id"));
                                     $('#'+controlId+'Fake').val($(this).data("row-name"));
                                     
                                     $('html, body').animate({
                                                scrollTop: $('#'+controlId+'Fake').offset().top-200
                                        }, 400);
                                        
                                     $(dialogResourceAnmGrid).dialog('close');
                                     
                                 }).end().find(".command-delete").on("click", function (e) {
                                     // alert("You pressed delete on row: " + $(this).data("row-id"));
                                 }).end().find(".command-add").on("click", function (e) {
                                     /* Yout button logic */
                                 });
                            });
                                    
                                    },
                            });
								
								
						}
						
						var dialogResourceSubGrid;
                        var bootgridSubResource;
                        function makeResourceSubGrids(controlId, title, roleId){
                        
                            dialogResourceSubGrid = $('#divIdentifiedBySubGrid').dialog({
                                autoOpen:true,
                                width:screen.width - 200,
                                height:540,
                                title: title,
                                modal: true,
                                buttons: {
                                    Cancel: function() {
                                        dialogResourceSubGrid.dialog( "close" );
                                    }
                                },
                                close: function() {
                                    $(bootgridSubResource).bootgrid('destroy');
                                },
                                open: function(){
                                        bootgridSubResource = $("#tableIdentifiedBySubGrid").bootgrid({
                                        
                                        ajax: true,
                                        url: "<?php echo site_url("Ajax/getSubList");?>"    ,
                                        post: function ()
                                        {
                                                /* To accumulate custom parameter with the request object */
                                                return {
                                                        id: "b0df282a-0d67-40e5-8558-c9e93b7befed",
                                                        roleId:roleId
                                                };
                                        },
                    css: {
                        icon: 'zmdi icon',
                        iconColumns: 'zmdi-view-module',
                        iconDown: 'zmdi-expand-more',
                        iconRefresh: 'zmdi-refresh',
                        iconUp: 'zmdi-expand-less'
                    },
                    formatters: {
                                            "commands": function (column, row) {
                                                    return "<a href=\"#\" type=\"button\" class=\"btn btn-icon command-edit waves-effect waves-circle\" data-row-id=\"" + row.SubCenterCode + "\" data-row-name=\"" + row.SubCenterName + "\"><span class=\"zmdi zmdi-plus\"></span></a>";                                                  
                                                }
                                        }
                }).on("loaded.rs.jquery.bootgrid", function () {
                                 //Remove event handlers
                                 $(this).find(".command-edit").off();
                                 $(this).find(".command-delete").off();
                                 $(this).find(".command-add").off();

                                 $(this).find(".command-edit").on("click", function (e) {
                                     /* make 2 buttons. one Having Fake suffix will have
                                      name and the one without suffix will be orignal control
                                     and will contain id */
                                     
                                     $('#'+controlId).val($(this).data("row-id"));
                                     $('#'+controlId+'Fake').val($(this).data("row-name"));
                                     
                                     $('html, body').animate({
                                                scrollTop: $('#'+controlId+'Fake').offset().top-200
                                        }, 400);
                                        
                                     $(dialogResourceSubGrid).dialog('close');
                                     
                                 }).end().find(".command-delete").on("click", function (e) {
                                     // alert("You pressed delete on row: " + $(this).data("row-id"));
                                 }).end().find(".command-add").on("click", function (e) {
                                     /* Yout button logic */
                                 });
                            });
                                    
                                    },
                            });
								
								
						}
						
						var dialogResourceVillageGrid;
                        var bootgridVillageResource;
                        function makeResourceVillageGrid(controlId, title, roleId){
                        
                            dialogResourceVillageGrid = $('#divIdentifiedByVillageGrid').dialog({
                                autoOpen:true,
                                width:screen.width - 200,
                                height:540,
                                title: title,
                                modal: true,
                                buttons: {
                                    Cancel: function() {
                                        dialogResourceVillageGrid.dialog( "close" );
                                    }
                                },
                                close: function() {
                                    $(bootgridVillageResource).bootgrid('destroy');
                                },
                                open: function(){
                                 bootgridVillageResource = $("#tableIdentifiedByVillageGrid").bootgrid({
                                        
                                        ajax: true,
                                        url: "<?php echo site_url("Ajax/getVillageList");?>"    ,
                                        post: function ()
                                        {
                                                /* To accumulate custom parameter with the request object */
                                                return {
                                                        id: "b0df282a-0d67-40e5-8558-c9e93b7befed",
                                                        roleId:roleId
                                                };
                                        },
                    css: {
                        icon: 'zmdi icon',
                        iconColumns: 'zmdi-view-module',
                        iconDown: 'zmdi-expand-more',
                        iconRefresh: 'zmdi-refresh',
                        iconUp: 'zmdi-expand-less'
                    },
                    formatters: {
                                            "commands": function (column, row) {
                                                    return "<a href=\"#\" type=\"button\" class=\"btn btn-icon command-edit waves-effect waves-circle\" data-row-id=\"" + row.VillageCode + "\" data-row-name=\"" + row.VillageName + "\"><span class=\"zmdi zmdi-plus\"></span></a>";                                                  
                                                }
                                        }
                }).on("loaded.rs.jquery.bootgrid", function () {
                                 //Remove event handlers
                                 $(this).find(".command-edit").off();
                                 $(this).find(".command-delete").off();
                                 $(this).find(".command-add").off();

                                 $(this).find(".command-edit").on("click", function (e) {
                                     /* make 2 buttons. one Having Fake suffix will have
                                      name and the one without suffix will be orignal control
                                     and will contain id */
                                     
                                     $('#'+controlId).val($(this).data("row-id"));
                                     $('#'+controlId+'Fake').val($(this).data("row-name"));
                                     
                                     $('html, body').animate({
                                                scrollTop: $('#'+controlId+'Fake').offset().top-200
                                        }, 400);
                                        
                                        
                                     $(dialogResourceVillageGrid).dialog('close');
                                     
                                 }).end().find(".command-delete").on("click", function (e) {
                                     // alert("You pressed delete on row: " + $(this).data("row-id"));
                                 }).end().find(".command-add").on("click", function (e) {
                                     /* Yout button logic */
                                 });
                            });
                                    
                                    },
                            });
								
								
						}
						</script>
						
						