         <section id="main">
            <aside id="sidebar" class="sidebar c-overflow">
                <div class="s-profile">
                    <a href="" data-ma-action="profile-menu-toggle">
                        <div class="sp-pic">
                            <img src="<?php echo site_url('common_libs'); ?>/img/msakhi_logo.png" alt="">
                        </div>

                        <div class="sp-info">
                            <?php 
								$loginData = $this->session->userdata('loginData');
								echo $loginData->user_name; 
							?>
                            <i class="zmdi zmdi-caret-down"></i>
                        </div>
                    </a>

                    <ul class="main-menu">
                        <li>
                            <a href="<?php echo site_url(); ?>login/logout"><i class="zmdi zmdi-time-restore"></i> Logout</a>
                        </li>
                    </ul>
                </div>

                <ul class="main-menu">
                    <li class="active">
                        <a href="<?php echo site_url(); ?>dashboard"><i class="zmdi zmdi-home"></i> Dashboard</a>
                    </li>
                    <li class="sub-menu">
                        <a href="" data-ma-action="submenu-toggle"><i class="zmdi zmdi-account-circle"></i> User Management</a>
                        <ul>
                            <li>
                                <li class="sub-menu">
                                    <a href="" data-ma-action="submenu-toggle"> ANM</a>
                                    <ul>
                                        <li><a href="<?php echo site_url('anm');?>">List ANM</a></li>
                                        <li><a href="<?php echo site_url('anm/add');?>">Add ANM</a></li>
                                    </ul>
                                </li>
                            </li>
                            <li class="sub-menu">
                        <a href="" data-ma-action="submenu-toggle"> ASHA</a>
                        <ul>
                            <li><a href="<?php echo site_url('asha');?>">List ASHA</a></li>
                            <li><a href="<?php echo site_url('asha/add');?>">Add ASHA</a></li>
                        </ul>
                    </li>
                     <li class="sub-menu">
                        <a href="" data-ma-action="submenu-toggle"> Users</a>
                        <ul>
                            <li><a href="<?php echo site_url('users');?>">List Users</a></li>
                            <li><a href="<?php echo site_url('users/add');?>">Add Users</a></li>
                        </ul>
                    </li>
                        </ul>
                    </li> 
                    <li class="sub-menu">
                    <a href="" data-ma-action="submenu-toggle"><i class="zmdi zmdi-my-location"></i> Manage Location</a>
                        <ul>
                            <li class="sub-menu">
                        <a href="" data-ma-action="submenu-toggle"> State</a>
                        <ul>
                            <li><a href="<?php echo site_url('state');?>">List State</a></li>
                            <li><a href="<?php echo site_url('state/add');?>">Add State</a></li>
                        </ul>
                    </li>
                    <li class="sub-menu">
                        <a href="" data-ma-action="submenu-toggle"> District</a>
                        <ul>
                            <li><a href="<?php echo site_url('district');?>">List District</a></li>
                            <li><a href="<?php echo site_url('district/add');?>">Add District</a></li>
                        </ul>
                    </li>
                    <li class="sub-menu">
                        <a href="" data-ma-action="submenu-toggle"> Block</a>
                        <ul>
                            <li><a href="<?php echo site_url('block');?>">List Block</a></li>
                            <li><a href="<?php echo site_url('block/add');?>">Add Block</a></li>
                        </ul>
                    </li>
                    <li class="sub-menu">
                        <a href="" data-ma-action="submenu-toggle"> Subcenter</a>
                        <ul>
                            <li><a href="<?php echo site_url('subcenter');?>">List Subcenter</a></li>
                            <li><a href="<?php echo site_url('subcenter/add');?>">Add Subcenter</a></li>
                        </ul>
                    </li>
                    <li class="sub-menu">
                        <a href="" data-ma-action="submenu-toggle"> Village</a>
                        <ul>
                            <li><a href="<?php echo site_url('village');?>">List Village</a></li>
                            <li><a href="<?php echo site_url('village/add');?>">Add Village</a></li>
                        </ul>
                    </li>
                    <li class="sub-menu">
                        <a href="" data-ma-action="submenu-toggle"> Panchayat</a>
                        <ul>
                            <li><a href="<?php echo site_url('panchayat');?>">List Panchayat</a></li>
                            <li><a href="<?php echo site_url('panchayat/add');?>">Add Panchayat</a></li>
                        </ul>
                    </li>
                        </ul>
                    </li>
                </ul>
            </aside>