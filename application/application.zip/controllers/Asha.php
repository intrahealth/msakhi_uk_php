<?php
class Asha extends CI_Controller {


	public function __construct(){
		parent::__construct();
		
		$this->load->model('Common_Model');
		
		$loginData = $this->session->userdata('loginData');
		if($loginData->user_type != 1){
			$this->session->set_flashdata('er_msg','You are not logged-in, please login again to continue');
			redirect('login');	
		}
	}
	

	function index() {
$query	=	"SELECT a.ANMName, b.SubCenterName , c.VillageName FROM mstanm a  
						INNER join mstsubcenter b  INNER JOIN mstvillage c on a.ANMID = b.SubCenterID and b.SubCenterID=c.VillageID AND b.LanguageID=1 AND a.LanguageID=1 and c.LanguageID=1";
							
		$RequestMethod = $this->input->server('REQUEST_METHOD');
		if($RequestMethod == "POST"){
			$query	=	"select * from mstasha where  LanguageID=1";					
			$content['Asha_list'] = $this->Common_Model->query_data($query);
		}else{
			$content['Asha_list'] = array();
		}	
		
		$query	=	"select * from mstasha where LanguageID=1 and IsDeleted=0";
		$content['Asha_list']	=	$this->Common_Model->query_data($query);
		
		$content['subview']="list_asha";
		$this->load->view('main_layout', $content);
	}
	
	function add(){
	
		$RequestMethod = $this->input->server('REQUEST_METHOD');
		if($RequestMethod == "POST"){
			
			$this->db->trans_start();
			
			$ANMCode	=	$this->input->get('ANMCode');
			$SubCenterCode	=	$this->input->get('SubCenterCode');
			$VillageCode	=	$this->input->get('VillageCode');
			
			//Get the AshaId, this is the Max(AshaId) column
			$query	=	"select max(ASHAID) as ASHAID from mstasha";
			$ashaLis	=	$this->Common_Model->query_data($query);
			$ashaId	=	$ashaLis[0]->ASHAID;
			
			//Get the AshaCode, THis is the max(ASHACode) column
			$query =	"select max(ASHACode) as ASHACode from mstasha";
			$ashaRec	=	$this->Common_Model->query_data($query);
			$ashaCode	=	$ashaRec[0]->ASHACode;

			$insertArr = array(
				 	
					//Record  for English LanguageID =1
				'ANMCode'				=> 	$ANMCode,
				'SubCenterCode'	=>	$SubCenterCode,
				'VillageCode'		=>	$VillageCode,
				'ASHAID'				=>	$ashaId+1,
				'ASHACode'			=> 	$ashaCode+1,
				'ASHAName'			=> 	$this->input->post('AshaNameEnglish'),
				'CHS_ID'				=>	$this->input->post('CHS_ID'),
				'LanguageID'		=> 1,
				'IsDeleted'			=> 0,
				
			);
			$this->Common_Model->insert_data('mstasha', $insertArr);
			
			$insertArr	=	array(
			//Record for Hindi LanguageID = 1
			
			'ANMCode'				=>	$ANMCode,
			'SubCenterCode'	=>	$SubCenterCode,
			'VillageCode'		=>	$VillageCode,
			'ASHAID'				=>	$ashaId+1,
			'ASHACode'			=>	$ashaCode+1,
			'ASHAName'			=>	$this->input->post('AshaNameHindi'),
			'CHS_ID'				=>	$this->input->post('CHS_ID'),
			'LanguageID'		=>	2,
			'IsDeleted'			=> 0,
			);
			$this->Common_Model->insert_data('mstasha', $insertArr);
			
			$this->db->trans_complete();
			
			$this->session->set_flashdata('tr_msg', 'Successfully added asha');
			
			if ($this->db->trans_status() === FALSE){
				$this->session->set_flashdata('tr_msg', 'Error adding Panchayat');					
			}else{
				$this->session->set_flashdata('tr_msg', 'Successfully added Panchayat');			
			}
			
			redirect('asha');
		}
		
		
		$content['subview']="add_asha";
		$this->load->view('main_layout', $content);
	}
	
	function edit($ashaCode=null){
	
		$RequestMethod = $this->input->server('REQUEST_METHOD');
		if($RequestMethod == "POST"){
			
			
			$this->db->trans_start();
			
			//Record   for English LanguageID=1
			$updateArr = array(
				
				'ASHAName'		=> $this->input->post('AshaNameEnglish'),
				'CHS_ID'			=>	$this->input->post('CHS_ID'),
				'LanguageID'		=> 1,
				'IsDeleted'			=> 0,
			);
			
						$this->db->where('AshaCode' , $ashaCode);
						$this->db->where('LanguageID', 1);
						$this->db->update('mstasha', $updateArr);
			
			//Record for Hindi LanguageID=2
			
			$updateArr	=	array(
							'ASHAName'	=>		$this->input->post('AshaNameHindi'),
							'CHS_ID'		=>	$this->input->post('CHS_ID'),
							'LanguageID'		=>	2,
							'IsDeleted'			=>	0,
				);
				
						$this->db->where('ASHACode' ,  $ashaCode);
						$this->db->where('LanguageID' , 2);
						$this->db->update('mstasha' , $updateArr);
						
						
						$this->db->trans_complete();
			
			$this->session->set_flashdata('tr_msg', 'Successfully updated asha');
			
			if ($this->db->trans_status() === FALSE){
						$this->session->set_flashdata('tr_msg', 'Error aedit Asha');					
					}else{
						$this->session->set_flashdata('tr_msg', 'Successfully edit Asha');			
					}
					
			redirect('asha');
		}
	
		$query = "select * from mstasha where LanguageID=1 and IsDeleted=0";
		$Asha_details = $this->Common_Model->query_data($query);
		
		if(count($Asha_details) < 1){
			$this->session->set_flashdata('er_msg', 'The record does not exist / permission denied. Please contact your system administrator.');
			redirect('asha');
		}
		
		$content['Asha_details'] = $Asha_details[0];
		$content['subview']="edit_asha";
		$this->load->view('main_layout', $content);
		
		
	}
	
	function delete($ashaCode=null){
	
		$query =  "update mstasha set IsDeleted = 1 where ASHACode=$ashaCode";
	
	 $this->db->query($query);
	 $this->session->set_flashdata('tr_msg' ,"Asha Deleted Successfully");
	 redirect('asha');
	}
	

}