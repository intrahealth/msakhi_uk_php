<?php
class Block extends CI_Controller {


	public function __construct(){
		parent::__construct();
		
		$this->load->model('Common_Model');
		
		$loginData = $this->session->userdata('loginData');
		if($loginData->user_type != 1){
			$this->session->set_flashdata('er_msg','You are not logged-in, please login again to continue');
			redirect('login');	
		}
	}
	

	function index() {
	
			$query = "select * from mststate where LanguageID=1";
			$content['State_List'] = $this->Common_Model->query_data($query);
			
			$RequestMethod = $this->input->server('REQUEST_METHOD');
		if($RequestMethod == "POST")
		{
			$query = "select * from mstdistrict where StateCode=".$this->input->post('StateCode')." and LanguageID=1";
			$content['District_List'] = $this->Common_Model->query_data($query);
			
			$query = "select * from mstblock where StateCode =".$this->input->post('StateCode')." and IsDeleted=0 "." and LanguageID=1";
			$content['Block_List'] = $this->Common_Model->query_data($query);
			
		}else{
			$content['District_List'] = array();
			$content['Block_List'] = array();
		
		}
		
			$content['subview']="list_block";
			$this->load->view('main_layout', $content);
	}
	
	function add(){
	
	
		$RequestMethod = $this->input->server('REQUEST_METHOD');
		if($RequestMethod == "POST"){
			
			$this->db->trans_start();
			
			$StateCode = $this->input->get('StateCode');
			$DistrictCode = $this->input->get('DistrictCode');
	
			//Get the BlockCode, THis is the max(BlockCode) column
			$sql=	"select max(BlockCode) as BlockCode from mstblock";
			$blockLis	=	$this->Common_Model->query_data($sql);
			$blockcode	=	$blockLis[0]->BlockCode;
		
		
		//Record For English LanguageID = 1

			$insertArr = array(
				'StateCode'			=>	$StateCode,
				'DistrictCode'  =>	$DistrictCode,
				'BlockCode'			=>	$blockcode+1,
				'BlockName'			=>	$this->input->post('BlockNameEnglish'),
				'LanguageID'		=>  1,
				'IsDeleted'			=>  0,
				
			);
		// print_r($insertArr); die();			
			$this->Common_Model->insert_data('mstblock', $insertArr);
			
			//Record For Hindi LanguageID=2
			$insertArr = array(
				'StateCode'			=>	$StateCode,
				'DistrictCode'	=>	$DistrictCode,
				'BlockCode'			=>	$blockcode+1,
				'BlockName'			=>	$this->input->post('BlockNameHindi'),
				'LanguageID'		=>  2,
				'IsDeleted'			=>	0,
				
			);
				$this->Common_Model->insert_data('mstblock', $insertArr);
				
				$this->session->set_flashdata('tr_msg', 'Successfully added block');
				
				$this->db->trans_complete();
				
			
			
			if ($this->db->trans_status() === FALSE){
				$this->session->set_flashdata('tr_msg', 'Error adding Block');					
			}else{
				$this->session->set_flashdata('tr_msg', 'Successfully added BLock');			
			}
			redirect('block');
		}
		
		$content['subview']="add_block";
		$this->load->view('main_layout', $content);
	}
	
	function edit($blockcode = NULL){
	
		$RequestMethod = $this->input->server('REQUEST_METHOD');
		if($RequestMethod == "POST"){
			
		if(!isset($_GET['step'])){
			//die('No Step Selected');
		}
			
			$this->db->trans_start();
			
			//Record for Enlish LanguageID=1
			$updateArr = array(				
				'BlockName'			=>	$this->input->post('BlockNameEnglish'),
				'LanguageID'		=> 	1,
				'IsDeleted'			=>	0,
			);
			
				$this->db->where('BlockCode' , $blockcode);
				$this->db->where('LanguageID' , 1);
				$this->db->update('mstblock' , $updateArr);
			
			
			//Record for Hindi LanguageID=2
			  $updateArr = array(
				'BlockName'		=>	$this->input->post('BlockNameHindi'),
				'LanguageID'	=>	2,
				'IsDeleted'		=>	0,
				);
				
					$this->db->where('BlockCode' , $blockcode);
					$this->db->where('LanguageID' , 2);
					$this->db->update('mstblock' , $updateArr);
			
			
			$this->db->trans_complete();
				
			$this->session->set_flashdata('tr_msg', 'Successfully updated block');
			
					if ($this->db->trans_status() === FALSE){
						$this->session->set_flashdata('tr_msg', 'Error adding state');					
					}else{
						$this->session->set_flashdata('tr_msg', 'Successfully added state');			
					}
			redirect('block');
		}
	
		$query = "select * from mstblock where BlockCode=$blockcode and IsDeleted=0";
		$Block_details = $this->Common_Model->query_data($query);
		
		if(count($Block_details) < 1){
			$this->session->set_flashdata('er_msg', 'The record does not exist / permission denied. Please contact your system administrator.');
			redirect('block');
		}
		
		$content['Block_details'] = $Block_details[0];
		$content['subview']="edit_block";
		$this->load->view('main_layout', $content);
		
		
	}
	
	function delete($blockcode =  NULL){
	
		$sql = "update mstblock	set IsDeleted = 1	where	BlockCode=$blockcode";
							
		$this->db->query($sql);
		$this->session->set_flashdata('tr_msg' ,"Block Deleted Successfully");
		redirect('block');
	}
	

}