<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Users extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		
		$this->load->model('Common_Model');
		
		$loginData = $this->session->userdata('loginData');
		if($loginData->user_type != 1){
			$this->session->set_flashdata('er_msg','You are not logged-in, please login again to continue');
			redirect('login');	
		}
	}

	public function index()
	{
		$query = "select * from tblusers where is_deleted = 0";
		$content['users_list'] = $this->Common_Model->query_data($query);
		
		$content['subview'] = "list_users";
		$this->load->view('main_layout', $content);
	}

	public function delete($id = null)
	{
		$sql = "update tblusers set is_deleted = 1 where user_id = $id";
		$this->db->query($sql);
		$this->session->set_flashdata('tr_msg' ,"User Deleted Successfully");
		redirect("users");
	}

	public function edit($id = null)
	{	

		$RequestMethod = $this->input->server('REQUEST_METHOD');

		if($RequestMethod == "POST")
		{
			$updateArray = array(
				'user_name' => $this->input->post('username'),
				'email' => $this->input->post('email'),
				'user_type' => $this->input->post('usertype'),
				'is_deleted' => 0,
				);

			if($this->input->post('password') !== null)
			{
				$updateArray['password'] = md5($this->input->post('password'));
			}

			$this->Common_Model->update_data('tblusers', $updateArray, 'user_id', $id);
			$this->session->set_flashdata('tr_msg', 'Successfully updated User');
			redirect('users');
		}


		$sql = "select * from tblusers where user_id = $id";
		$content['user_data'] = $this->Common_Model->query_data($sql)[0];

		$content['subview'] = 'edit_user';
		$this->load->view('main_layout', $content);
	}

	public function add()
	{	
		$RequestMethod = $this->input->server('REQUEST_METHOD');

		if($RequestMethod == "POST")
		{
			$insertArray = array(
				'user_name' => $this->input->post('username'),
				'email' => $this->input->post('email'),
				'password' => md5($this->input->post('password')),
				'user_type' => $this->input->post('usertype'),
				'is_deleted' => 0,
				);

			$this->Common_Model->insert_data('tblusers', $insertArray);
			$this->session->set_flashdata('tr_msg', 'Successfully added User');
			redirect('users');
		}


		$content['subview'] = 'add_user';
		$this->load->view('main_layout', $content);
	}
}