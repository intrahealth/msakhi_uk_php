<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
	}
	public function index()
	{	
		$this->load->view('components/login');
	}

	public function verifylogin()
	{
		$email = $this->security->xss_clean($this->input->post('email'));
		$password = $this->security->xss_clean($this->input->post('password'));

		$this->db->where('email', $email);
		$this->db->where('password', md5($password));
		$res = $this->db->get('tblusers');

		if($res->num_rows() == 1)
		{
			$row = $res->row();
			$this->session->set_userdata('loginData', $row);
			redirect('dashboard');
		}
		else
		{
			redirect('login');
		}
	}

	public function logout()
	{
	
		$this->session->set_flashdata('er_msg', 'Please login agin to continue...');
		$this->session->sess_destroy('loginData');
		redirect('login');
	}

}
