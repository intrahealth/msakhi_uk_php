<?php
class District extends CI_Controller {


	public function __construct(){
		parent::__construct();
		
		$this->load->model('Common_Model');
		
		$loginData = $this->session->userdata('loginData');
		if($loginData->user_type != 1){
			$this->session->set_flashdata('er_msg','You are not logged-in, please login again to continue');
			redirect('login');	
		}
	}
	

	function index() {
		
		
		// to fill the upper container
		$query = "select * from mststate where LanguageID = 1";
		$content['State_list'] = $this->Common_Model->query_data($query);
		
		// to fill the bottom list
		if(isset($_GET['StateCode'])){
			$StateCode = trim($_GET['StateCode']);
			$query = "select * from mstdistrict where StateCode = $StateCode and IsDeleted=0 and LanguageID = 1";
			$result = $this->Common_Model->query_data($query);
		}else{
			$result = array();
		}
		
		$content['District_list'] = $result;
		
		//print_r($content['district_list']); 
		//die();
	
		$content['subview']="list_district";
		$this->load->view('main_layout', $content);
	}
	
	function add($statecode=null){
	
		$RequestMethod = $this->input->server('REQUEST_METHOD');
		if($RequestMethod == "POST"){
			
			$this->db->trans_start();
			
		// get the DistrictCode, This is the max(DistrictCode) column
				$query = "select max(DistrictCode) as DistrictCode from mstdistrict";
				$districtCod	=	$this->Common_Model->query_data($query);
				$districtcode = $districtCod[0]->DistrictCode;
				
		//Record For English LanguageID = 1

					$insertArr = array(
						'StateCode'					=> $statecode,
						'DistrictCode'			=>	$districtcode+1,
						'DistrictName'			=>	$this->input->post('DistrictNameEnglish'),
						'LanguageID'				=> 	1,
						'IsDeleted'					=>	0,
					);
					
			$this->Common_Model->insert_data('mstdistrict', $insertArr);
			
			//Record For Hindi LanguageID = 2
					$insertArr = array(
						'StateCode'					=>	$statecode,
						'DistrictCode'			=>	$districtcode+1,
						'DistrictName'			=>	$this->input->post('DistrictNameHindi'),
						'LanguageID'				=> 	2,
						'IsDeleted'					=>	0,
					);
			
			$this->Common_Model->insert_data('mstdistrict', $insertArr);
			
			$this->session->set_flashdata('tr_msg', 'Successfully added district');
			
			$this->db->trans_complete();
			
			if ($this->db->trans_status() === FALSE){
				$this->session->set_flashdata('tr_msg', 'Error adding Anm');					
			}else{
				$this->session->set_flashdata('tr_msg', 'Successfully added Anm');			
			}
			
			redirect('district');
		}
			
			$content['subview']="add_district";
			$this->load->view('main_layout', $content);
	}
	
	function edit($districtcode=null){
	
		$RequestMethod = $this->input->server('REQUEST_METHOD');
		if($RequestMethod == "POST"){
			
			if(!isset($_GET['step'])){
			//die('No Step Selected');
		}
			
			$this->db->trans_start();
	
			//Record for English LanguageID=1
			$updateArr = array(
				'DistrictName'			=>	$this->input->post('DistrictNameEnglish'),
				'LanguageID'		=> 1,
				'IsDeleted'	=>	0,
			);
			
					$this->db->where('DistrictCode' , $districtcode);
					$this->db->where('LanguageID', 1);
					$this->db->update('mstdistrict', $updateArr);
			
			//Record for Hindi LanguageID=2
				$updateArr = array(
				'DistrictName'			=>	$this->input->post('DistrictNameHindi'),
				'LanguageID'		=> 2,
				'IsDeleted'	=>	0,
			);
		
						$this->db->where('DistrictCode' , $districtcode);
						$this->db->where('LanguageID', 2);
						$this->db->update('mstdistrict' , $updateArr);
						
					$this->db->trans_complete();
				
					$this->session->set_flashdata('tr_msg', 'Successfully updated district');
			
					if ($this->db->trans_status() === FALSE){
						$this->session->set_flashdata('tr_msg', 'Error adding state');					
					}else{
						$this->session->set_flashdata('tr_msg', 'Successfully added state');			
					}
			
			redirect('district');
		}
		
			$query = "select * from mstdistrict where DistrictCode=$districtcode and IsDeleted=0";
			$District_details = $this->Common_Model->query_data($query);
			
		if(count($District_details) < 1){
			$this->session->set_flashdata('er_msg', 'The record does not exist / permission denied. Please contact your system administrator.');
			redirect('district');
		}
			
			$content['District_details'] = $District_details[0];
			$content['subview']="edit_district";
			$this->load->view('main_layout', $content);
		
		
	}
	
	function delete($districtcode=null){
	
		$query = "update mstdistrict
							set IsDeleted = 1
							where DistrictCode=$districtcode";
			
		 $this->db->query($query);
		 $this->session->set_flashdata('tr_msg' ,"District Deleted Successfully");
		 redirect('district');
	}
	

}